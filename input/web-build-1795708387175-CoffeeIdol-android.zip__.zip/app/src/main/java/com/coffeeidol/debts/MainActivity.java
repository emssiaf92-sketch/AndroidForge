package com.coffeeidol.debts;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient()); // لإظهار التنبيهات
        // نحمّل الصفحة بعنوان https حتى يشتغل Firebase
        try (java.io.InputStream in = getAssets().open("index.html");
             java.util.Scanner sc = new java.util.Scanner(in, "UTF-8")) {
            web.loadDataWithBaseURL("https://localhost/", sc.useDelimiter("\\A").next(), "text/html", "UTF-8", null);
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
        setContentView(web);
    }
}

package com.coffeeidol.debts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private static final int SAVE = 1;
    private String pending;

    // حفظ النسخة الاحتياطية بالمكان الذي يختاره المستخدم
    private class Bridge {
        @JavascriptInterface
        public void saveFile(final String name, final String text) {
            runOnUiThread(() -> {
                pending = text;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(i, SAVE); }
                catch (Exception e) { toast("تعذر فتح نافذة الحفظ"); }
            });
        }
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code != SAVE || result != RESULT_OK || data == null) return;
        if (pending == null) { toast("لم تحفظ النسخة، حاول مرة ثانية"); return; }
        try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData())) {
            out.write(pending.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            toast("تم حفظ النسخة الاحتياطية");
        } catch (Exception e) { toast("فشل حفظ النسخة"); }
        pending = null;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        web.setWebChromeClient(new WebChromeClient()); // لإظهار التنبيهات
        // نحمّل الصفحة بعنوان https حتى يشتغل Firebase
        try (java.io.InputStream in = getAssets().open("index.html");
             java.util.Scanner sc = new java.util.Scanner(in, "UTF-8")) {
            web.loadDataWithBaseURL("https://localhost/", sc.useDelimiter("\\A").next(), "text/html", "UTF-8", null);
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
        setContentView(web);
    }
}

كوفي ايدل — مشروع Android لتحويل صفحة HTML إلى تطبيق APK

المحتويات:
- تطبيق Android بسيط يستخدم WebView لعرض التطبيق الأصلي.
- تم تفعيل JavaScript و DOM Storage حتى تعمل localStorage وتبقى بيانات الديون محفوظة على الجهاز.
- لا يحتاج التطبيق إلى اتصال بالإنترنت.

طريقة إنشاء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) فك ضغط CoffeeIdolAndroid.zip.
3) من Android Studio اختر Open وافتح مجلد CoffeeIdolAndroid.
4) انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طلبه البرنامج.
5) من القائمة Build > Build Bundle(s) / APK(s) > Build APK(s).
6) بعد اكتمال البناء اختر Locate. ملف التثبيت سيكون عادةً:
   app/build/outputs/apk/debug/app-debug.apk

لإصدار نسخة نهائية موقعة للنشر:
Build > Generate Signed Bundle / APK > APK.

ملاحظة:
هذا المشروع جاهز للبناء في Android Studio، لكنه ليس ملف APK مُجمّعاً بحد ذاته.
بيئة التنفيذ هنا لا تحتوي Android SDK أو Gradle، لذلك لم أتمكن من تجميع APK فعلياً.
